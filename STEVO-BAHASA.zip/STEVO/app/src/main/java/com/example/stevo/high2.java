package com.example.stevo;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class high2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_high2);
    }

    public void Stage1(View v) {
        Intent intent = new Intent(high2.this, StarCycle.class);
        startActivity(intent);
        high2.this.finish();
    }

    public void Next(View v) {
        Intent intent = new Intent(high2.this, high3.class);
        startActivity(intent);
        high2.this.finish();
    }
}