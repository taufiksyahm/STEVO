package com.example.stevo;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class intermediate4 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_intermediate4);
    }

    public void Stage1(View v) {
        Intent intent = new Intent(intermediate4.this, StarCycle.class);
        startActivity(intent);
        intermediate4.this.finish();
    }

    public void Stage2(View v) {
        Intent intent = new Intent(intermediate4.this, intermediate2.class);
        startActivity(intent);
        intermediate4.this.finish();
    }

    public void Stage3(View v) {
        Intent intent = new Intent(intermediate4.this, intermediate3.class);
        startActivity(intent);
        intermediate4.this.finish();
    }

    public void Next(View v) {
        Intent intent = new Intent(intermediate4.this, intermediate5.class);
        startActivity(intent);
        intermediate4.this.finish();
    }
}