package com.example.stevo;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class Calculator extends AppCompatActivity {
    EditText radiation, distance, mass, oradiation, odistance, omass;
    TextView rate, second, day, year, nrate, nage, ntime;
    Button count;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_calculator);
        radiation =(EditText)findViewById(R.id.ET_I1);
        oradiation =(EditText)findViewById(R.id.ET_E1);
        distance =(EditText)findViewById(R.id.ET_I2);
        odistance =(EditText)findViewById(R.id.ET_E2);
        mass =(EditText)findViewById(R.id.ET_I3);
        omass =(EditText)findViewById(R.id.ET_E3);
        rate = (TextView)findViewById(R.id.TV_C1);
        second =(TextView) findViewById(R.id.TV_C2);
        day =(TextView) findViewById(R.id.TV_C3);
        year =(TextView) findViewById(R.id.TV_C4);
        count = (Button)findViewById(R.id.B_Count);
        nrate = (TextView) findViewById(R.id.TV_TC1);
        nage = (TextView) findViewById(R.id.TV_TC2);
        ntime = (TextView) findViewById(R.id.TV_TC3);
    }
    public void hitung (View view){
        try {
            float iradiation = Float.parseFloat(radiation.getText().toString());
            float idistance = Float.parseFloat(distance.getText().toString());
            float imass = Float.parseFloat(mass.getText().toString());
            float ioradiation = Float.parseFloat(oradiation.getText().toString());
            float iodistance = Float.parseFloat(odistance.getText().toString());
            float iomass = Float.parseFloat(omass.getText().toString());
            double olaju = (4*3.14*idistance*Math.pow(10,iodistance)*idistance*Math.pow(10,iodistance)*iradiation*Math.pow(10,ioradiation))/(3E8*3E8);
            double osekon = (imass*Math.pow(10,iomass))/olaju;
            double ohari = (imass*Math.pow(10,iomass))/(olaju*86400);
            double otahun = (imass*Math.pow(10,iomass))/(olaju*31536000);

            rate.setVisibility(View.VISIBLE);
            second.setVisibility(View.VISIBLE);
            day.setVisibility(View.VISIBLE);
            nrate.setVisibility(View.VISIBLE);
            nage.setVisibility(View.VISIBLE);
            year.setVisibility(View.VISIBLE);
            ntime.setVisibility(View.VISIBLE);

            rate.setText(String.valueOf(olaju) +" kg/s");
            second.setText(String.valueOf(osekon) +" s");
            day.setText(String.valueOf(ohari) +" hari");
            year.setText(String.valueOf(otahun) +" tahun");

        }catch (Exception e){
            e.printStackTrace();
        }
    }
}