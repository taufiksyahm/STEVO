package com.example.stevo;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class high3 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_high3);
    }

    public void Stage1(View v) {
        Intent intent = new Intent(high3.this, StarCycle.class);
        startActivity(intent);
        high3.this.finish();
    }

    public void Stage2(View v) {
        Intent intent = new Intent(high3.this, high2.class);
        startActivity(intent);
        high3.this.finish();
    }

    public void Next(View v) {
        Intent intent = new Intent(high3.this, high4.class);
        startActivity(intent);
        high3.this.finish();
    }
}