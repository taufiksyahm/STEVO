package com.example.stevo;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class low3 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_low3);
    }

    public void Stage1(View v) {
        Intent intent = new Intent(low3.this, StarCycle.class);
        startActivity(intent);
        low3.this.finish();
    }

    public void Stage2(View v) {
        Intent intent = new Intent(low3.this, low2.class);
        startActivity(intent);
        low3.this.finish();
    }

    public void Start(View v) {
        Intent intent = new Intent(low3.this, StarCycle.class);
        startActivity(intent);
        low3.this.finish();
    }

    public void Home(View v) {
        Intent intent = new Intent(low3.this, MainActivity.class);
        startActivity(intent);
        low3.this.finish();
    }

}