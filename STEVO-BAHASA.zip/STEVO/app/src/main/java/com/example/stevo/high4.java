package com.example.stevo;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class high4 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_high4);
    }

    public void Stage1(View v) {
        Intent intent = new Intent(high4.this, StarCycle.class);
        startActivity(intent);
        high4.this.finish();
    }

    public void Stage2(View v) {
        Intent intent = new Intent(high4.this, high2.class);
        startActivity(intent);
        high4.this.finish();
    }

    public void Stage3(View v) {
        Intent intent = new Intent(high4.this, high3.class);
        startActivity(intent);
        high4.this.finish();
    }

    public void less3(View v) {
        Intent intent = new Intent(high4.this, less3.class);
        startActivity(intent);
        high4.this.finish();
    }

    public void more3(View v) {
        Intent intent = new Intent(high4.this, more3.class);
        startActivity(intent);
        high4.this.finish();
    }
}