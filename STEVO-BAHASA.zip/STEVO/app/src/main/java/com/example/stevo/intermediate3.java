package com.example.stevo;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class intermediate3 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_intermediate3);
    }

    public void Stage1(View v) {
        Intent intent = new Intent(intermediate3.this, StarCycle.class);
        startActivity(intent);
        intermediate3.this.finish();
    }

    public void Stage2(View v) {
        Intent intent = new Intent(intermediate3.this, intermediate2.class);
        startActivity(intent);
        intermediate3.this.finish();
    }

    public void Next(View v) {
        Intent intent = new Intent(intermediate3.this, intermediate4.class);
        startActivity(intent);
        intermediate3.this.finish();
    }
}