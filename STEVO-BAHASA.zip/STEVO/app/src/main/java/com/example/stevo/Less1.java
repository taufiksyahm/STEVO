package com.example.stevo;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class Less1 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_less1);
    }

    public void Stage1(View v) {
        Intent intent = new Intent(Less1.this, StarCycle.class);
        startActivity(intent);
        Less1.this.finish();
    }

    public void Start(View v) {
        Intent intent = new Intent(Less1.this, StarCycle.class);
        startActivity(intent);
        Less1.this.finish();
    }

    public void Home(View v) {
        Intent intent = new Intent(Less1.this, MainActivity.class);
        startActivity(intent);
        Less1.this.finish();
    }

}