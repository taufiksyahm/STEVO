package com.example.stevo;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class intermediate5 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_intermediate5);
    }

    public void Stage1(View v) {
        Intent intent = new Intent(intermediate5.this, StarCycle.class);
        startActivity(intent);
        intermediate5.this.finish();
    }

    public void Stage2(View v) {
        Intent intent = new Intent(intermediate5.this, intermediate2.class);
        startActivity(intent);
        intermediate5.this.finish();
    }

    public void Stage3(View v) {
        Intent intent = new Intent(intermediate5.this, intermediate3.class);
        startActivity(intent);
        intermediate5.this.finish();
    }

    public void Stage4(View v) {
        Intent intent = new Intent(intermediate5.this, intermediate4.class);
        startActivity(intent);
        intermediate5.this.finish();
    }

    public void Start(View v) {
        Intent intent = new Intent(intermediate5.this, StarCycle.class);
        startActivity(intent);
        intermediate5.this.finish();
    }

    public void Home(View v) {
        Intent intent = new Intent(intermediate5.this, MainActivity.class);
        startActivity(intent);
        intermediate5.this.finish();
    }

}