package com.example.stevo;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void Videos(View view) {
        Intent intent = new Intent(MainActivity.this, Videos.class);
        startActivity(intent);
    }

    public void Calculator(View view) {
        Intent intent = new Intent(MainActivity.this, Calculator.class);
        startActivity(intent);
    }

    public void Cycle(View v) {
        Intent intent = new Intent(MainActivity.this, StarCycle.class);
        startActivity(intent);
    }
    public void About(View view) {
        Intent intent = new Intent(MainActivity.this, About.class);
        startActivity(intent);
    }
}