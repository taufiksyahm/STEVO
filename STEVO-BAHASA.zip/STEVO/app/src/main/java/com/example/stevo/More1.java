package com.example.stevo;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class More1 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_more1);
    }

    public void Stage1(View v) {
        Intent intent = new Intent(More1.this, StarCycle.class);
        startActivity(intent);
        More1.this.finish();
    }

    public void Low(View v) {
        Intent intent = new Intent(More1.this, low2.class);
        startActivity(intent);
        More1.this.finish();
    }

    public void Intermediate(View v) {
        Intent intent = new Intent(More1.this, intermediate2.class);
        startActivity(intent);
        More1.this.finish();
    }

    public void High(View v) {
        Intent intent = new Intent(More1.this, high2.class);
        startActivity(intent);
        More1.this.finish();
    }
}