package com.example.stevo;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.MediaController;
import android.widget.VideoView;

import com.pierfrancescosoffritti.androidyoutubeplayer.core.player.YouTubePlayer;
import com.pierfrancescosoffritti.androidyoutubeplayer.core.player.listeners.AbstractYouTubePlayerListener;
import com.pierfrancescosoffritti.androidyoutubeplayer.core.player.views.YouTubePlayerView;

public class Videos extends AppCompatActivity {
    private YouTubePlayerView YTPV;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_videos);

        YTPV = findViewById(R.id.youtube_player_view);
        getLifecycle().addObserver(YTPV);

        YTPV.addYouTubePlayerListener(new AbstractYouTubePlayerListener() {
            @Override
            public void onReady(YouTubePlayer youTubePlayer) {
                String videoid = "0_-zJ2LhMSU";
                youTubePlayer.loadVideo(videoid,0);
            }
        });

    }
    public void Calculator(View view) {
        Intent intent = new Intent(Videos.this, Calculator.class);
        startActivity(intent);
        Videos.this.finish();
    }

    public void Cycle(View view) {
        Intent intent = new Intent(Videos.this, StarCycle.class);
        startActivity(intent);
        Videos.this.finish();
    }

}